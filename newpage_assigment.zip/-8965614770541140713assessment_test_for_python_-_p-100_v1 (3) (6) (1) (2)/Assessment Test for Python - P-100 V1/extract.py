import pandas as pd
input_xl = 'C:\\Users\\ashok\\Downloads\\-8965614770541140713assessment_test_for_python_-_p-100_v1 (3) (6) (1) (2)\\Assessment Test for Python - P-100 V1\\Analytics Template for Exercise.xlsx'
output_xl = 'C:\\Users\\ashok\\Downloads\\-8965614770541140713assessment_test_for_python_-_p-100_v1 (3) (6) (1) (2)\\Assessment Test for Python - P-100 V1\\output.xlsx'
COLUMN_NAMES = ['Day of Month','Date','Site ID','Page Views','Unique Visitors','Total Time Spent','Visits','Average Time Spent on Site']

input_df = pd.read_excel(input_xl)
final = pd.DataFrame(columns=COLUMN_NAMES)
current_index = 0
while current_index<len(input_df):
    sliced = input_df.iloc[current_index:current_index+3]
    current_index+=3
    sliced.columns=sliced. iloc[0]
    site_id = sliced.iloc[2,0]
    dates = sliced.iloc[1].drop_duplicates().values.flatten().tolist()
    dates.pop(0)
    for date in dates:
        interim = pd.DataFrame(columns=COLUMN_NAMES)
        for cols in range(1,len(sliced.columns.values.flatten().tolist())):
            col_name = sliced.columns.values.flatten().tolist()
            if sliced.iloc[1,cols]==date:
                if sliced.iloc[0,cols]=='Page Views':
                    page_view = sliced.iloc[2,cols]
            if sliced.iloc[1,cols]==date:
                if sliced.iloc[0,cols]=='Unique Visitors':
                    uniq_visitor = sliced.iloc[2,cols]
            if sliced.iloc[1,cols]==date:
                if sliced.iloc[0,cols]=='Total Time Spent':
                    total_time = sliced.iloc[2,cols]
            if sliced.iloc[1,cols]==date:
                if sliced.iloc[0,cols]=='Visits':
                    visits = sliced.iloc[2,cols]
            if sliced.iloc[1,cols]==date:
                if sliced.iloc[0,cols]=='Average Time Spent on Site':
                    avg_time = sliced.iloc[2,cols]
        data = [[date.strftime("%d"),date.date(),site_id,page_view,uniq_visitor,total_time,visits,avg_time]]
        interim = pd.DataFrame(data, columns = COLUMN_NAMES)
        final = final.append(interim)
final.to_excel(output_xl, index=False)
